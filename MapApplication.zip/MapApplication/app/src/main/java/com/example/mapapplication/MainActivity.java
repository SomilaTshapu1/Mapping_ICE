package com.example.mapapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.location.Location;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.mapbox.android.core.location.LocationEngine;
import com.mapbox.android.core.location.LocationEngineListener;
import com.mapbox.android.core.location.LocationEnginePriority;
import com.mapbox.android.core.location.LocationEngineProvider;
import com.mapbox.android.core.permissions.PermissionsListener;
import com.mapbox.android.core.permissions.PermissionsManager;
import com.mapbox.api.directions.v5.models.DirectionsResponse;
import com.mapbox.api.directions.v5.models.DirectionsRoute;
import com.mapbox.geojson.Point;
import com.mapbox.mapboxsdk.Mapbox;
import com.mapbox.mapboxsdk.annotations.Marker;
import com.mapbox.mapboxsdk.annotations.MarkerOptions;
import com.mapbox.mapboxsdk.camera.CameraUpdateFactory;
import com.mapbox.mapboxsdk.constants.Style;
import com.mapbox.mapboxsdk.geometry.LatLng;
import com.mapbox.mapboxsdk.maps.MapView;
import com.mapbox.mapboxsdk.maps.MapboxMap;
import com.mapbox.mapboxsdk.maps.OnMapReadyCallback;
import com.mapbox.mapboxsdk.plugins.locationlayer.LocationLayerPlugin;
import com.mapbox.mapboxsdk.plugins.locationlayer.modes.CameraMode;
import com.mapbox.mapboxsdk.plugins.locationlayer.modes.RenderMode;
import com.mapbox.services.android.navigation.ui.v5.NavigationLauncher;
import com.mapbox.services.android.navigation.ui.v5.NavigationLauncherOptions;
import com.mapbox.services.android.navigation.ui.v5.route.NavigationMapRoute;
import com.mapbox.services.android.navigation.v5.navigation.NavigationRoute;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback,
        LocationEngineListener, PermissionsListener, MapboxMap.OnMapClickListener
{

    private MapView mapview;
    private MapboxMap map;
    private Button btnNavigate;
    private PermissionsManager permManager;
    private LocationEngine locaEng;
    private LocationLayerPlugin LocaLayerPlug;
    private Location currentLoca;
    private Point currentPosi;
    private com.mapbox.geojson.Point destinPosi;
    private Marker destinMarker;
    private NavigationMapRoute nMapRoute;
    private static final String TAG = "Map";
    private Button darkMode;
    private  Button trafficDay;
    private  Button sat;


    //References
    //https://docs.mapbox.com/help/tutorials/android-runtime-styling-intro/
    //https://docs.mapbox.com/android/maps/examples/dynamically-build-a-map-view/

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        Mapbox.getInstance(this,"pk.eyJ1IjoidW5hdGhpIiwiYSI6ImNrZ2hxenprdDBnYnkyemxpMzVsb3QydW4ifQ.j0UmsT73cFreZWaYrbLqeg");
        setContentView(R.layout.activity_main);
        mapview = (MapView) findViewById(R.id.mapview);
        btnNavigate = (Button) findViewById(R.id.btnNavigate);
        mapview.onCreate(savedInstanceState);
        mapview.getMapAsync(this);

        //satellite view button
        sat = findViewById(R.id.sat);
        sat.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                mapview.getMapAsync(new OnMapReadyCallback()
                {
                    @Override
                    public void onMapReady(@NonNull MapboxMap mapboxMap)
                    {
                        mapboxMap.setStyle(Style.SATELLITE_STREETS, new MapboxMap.OnStyleLoadedListener()
                        {
                            @Override
                            public void onStyleLoaded(@NonNull String style)
                            {
                                enableLocation();
                            }
                        });

                    }
                });
            }
        });


        //traffic view button
        trafficDay = (Button) findViewById(R.id.traficDay);
        trafficDay.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                mapview.getMapAsync(new OnMapReadyCallback()
                {
                    @Override
                    public void onMapReady(@NonNull MapboxMap mapboxMap)
                    {
                        mapboxMap.setStyle(Style.TRAFFIC_DAY, new MapboxMap.OnStyleLoadedListener()
                        {
                            @Override
                            public void onStyleLoaded(@NonNull String style)
                            {
                                enableLocation();
                            }
                        });

                    }
                });
            }
        });


        //dark mode button

        darkMode = findViewById(R.id.darkMode);
        darkMode.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                mapview.getMapAsync(new OnMapReadyCallback()
                {
                    @Override
                    public void onMapReady(@NonNull MapboxMap mapboxMap)
                    {
                        mapboxMap.setStyle(Style.DARK, new MapboxMap.OnStyleLoadedListener()
                        {
                            @Override
                            public void onStyleLoaded(@NonNull String style)
                            {
                                enableLocation();
                            }
                        });

                    }
                });
            }
        });



        //Navigation button
        btnNavigate.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                NavigationLauncherOptions options = NavigationLauncherOptions.builder()
                        .origin(currentPosi).destination(destinPosi).shouldSimulateRoute(true)
                        .build();

                NavigationLauncher.startNavigation(com.example.mapapplication.MainActivity.this,options);
            }
        });

    }

    /**                REFERENCES
     https://docs.mapbox.com/android/maps/overview/
     https://www.youtube.com/watch?v=Ok9v0YYgIG4&t=611s
     https://www.youtube.com/watch?v=2rclnd8OKHU
     https://www.youtube.com/watch?v=TtRfCwwpQ3E
     https://www.youtube.com/watch?v=gOIbl8FtW_s
     https://docs.mapbox.com/help/tutorials/android-navigation-sdk/
     **/

    @Override
    public void onMapReady(MapboxMap mapboxMap)
    {
        map = mapboxMap;
        map.addOnMapClickListener(this);
        enableLocation();
    }

    private void enableLocation()
    {
        if(PermissionsManager.areLocationPermissionsGranted(this))
        {
            initializeLocationEngine();
            initializeLocationLayer();
        }
        else
        {
            permManager = new PermissionsManager(this);
            permManager.requestLocationPermissions(this);
        }
    }
    private void initializeLocationEngine()
    {
        locaEng = new LocationEngineProvider(this).obtainBestLocationEngineAvailable();
        locaEng.setPriority(LocationEnginePriority.HIGH_ACCURACY);
        locaEng.activate();

        Location lastLocation = locaEng.getLastLocation();
        if(lastLocation != null)
        {
            currentLoca = lastLocation;
            setCameraLocation(lastLocation);
        }
        else
        {
            locaEng.addLocationEngineListener(this);
        }

    }

    private void initializeLocationLayer()
    {
        LocaLayerPlug = new LocationLayerPlugin(mapview, map, locaEng);
        LocaLayerPlug.setLocationLayerEnabled(true);
        LocaLayerPlug.setCameraMode(CameraMode.TRACKING);
        LocaLayerPlug.setRenderMode(RenderMode.GPS);
    }

    private void setCameraLocation(Location loca)
    {
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(loca.getLatitude(),
                loca.getLongitude()),13.0));
    }

    @Override
    public void onMapClick(@NonNull LatLng point)
    {
        if(destinMarker != null)
        {
            map.removeMarker(destinMarker);
        }

        destinMarker = map.addMarker(new MarkerOptions().position(point));
        destinPosi = com.mapbox.geojson.Point.fromLngLat(point.getLongitude(),point.getLatitude());
        currentPosi = com.mapbox.geojson.Point.fromLngLat(currentLoca.getLongitude(),currentLoca.getLatitude());
        getRoute(currentPosi, destinPosi);
        btnNavigate.setEnabled(true);
        btnNavigate.setBackgroundResource(R.color.mapbox_navigation_route_layer_congestion_yellow);
    }

    private void getRoute(Point origin, Point destination)
    {
        NavigationRoute.builder().accessToken(Mapbox.getAccessToken()).origin(origin).destination(destination)
                .build().getRoute(new Callback<DirectionsResponse>()
        {
            @Override
            public void onResponse(Call<DirectionsResponse> call, Response<DirectionsResponse> response)
            {
                if(response.body() == null)
                {
                    Log.e(TAG,"Check user and access token");
                    return;
                }
                else if(response.body().routes().size()==0)
                {
                    Log.e(TAG, "No routes found");
                    return;
                }

                DirectionsRoute currentRoute = response.body().routes().get(0);
                if(nMapRoute != null)
                {
                    nMapRoute.removeRoute();
                }
                else
                {
                    nMapRoute = new NavigationMapRoute(null, mapview, map);
                }

                nMapRoute.addRoute(currentRoute);


            }

            @Override
            public void onFailure(Call<DirectionsResponse> call, Throwable t)
            {
                Log.e(TAG,"Error "+t.getMessage()+" occured");
            }
        });
    }

    @Override
    public void onConnected()
    {
        locaEng.requestLocationUpdates();
    }

    @Override
    public void onLocationChanged(Location location)
    {
        if(location != null)
        {
            currentLoca = location;
            setCameraLocation(location);
        }
    }

    @Override
    public void onExplanationNeeded(List<String> permissionsToExplain)
    {
        Toast toast=Toast.makeText(getApplicationContext()," ",Toast.LENGTH_SHORT);
    }

    @Override
    public void onPermissionResult(boolean granted)
    {
        if(granted)
        {
            enableLocation();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        permManager.onRequestPermissionsResult(requestCode,permissions,grantResults);
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        if(locaEng != null)
        {
            locaEng.requestLocationUpdates();
        }
        if(LocaLayerPlug != null)
        {
            LocaLayerPlug.onStop();
        }

        mapview.onStart();

    }

    @Override
    protected void onResume ()
    {
        super.onResume();
        mapview.onResume();
    }

    @Override
    protected void onPause ()
    {
        super.onPause();
        mapview.onPause();
    }

    @Override
    protected void onStop ()
    {
        super.onStop();
        if(locaEng != null)
        {
            locaEng.removeLocationUpdates();
        }
        if(LocaLayerPlug != null)
        {
            LocaLayerPlug.onStop();
        }
        mapview.onStop();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapview.onSaveInstanceState(outState);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapview.onLowMemory();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(locaEng != null)
        {
            locaEng.deactivate();
        }
        mapview.onDestroy();
    }
}